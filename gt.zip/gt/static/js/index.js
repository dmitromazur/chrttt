import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import {
    AuthProvider
} from "./utils/useAuthContext";
import {
    BrowserRouter
} from "react-router-dom";
import {
    ModalProvider
} from "./utils/ModalContext";
import {
    SoundProvider
} from "./utils/useSounds";
import {
    UserSocketDataProvider
} from "./utils/useUserSocket";
import {
    NotificationProvider
} from "./utils/NotificationProvider";
import {
    PreferencesProvider
} from "./utils/PreferencesProvider";

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render( <
    BrowserRouter >
    <
    PreferencesProvider >
    <
    NotificationProvider >
    <
    AuthProvider >
    <
    UserSocketDataProvider >
    <
    ModalProvider >
    <
    SoundProvider >
    <
    App / >
    <
    /SoundProvider> <
    /ModalProvider> <
    /UserSocketDataProvider> <
    /AuthProvider> <
    /NotificationProvider> <
    /PreferencesProvider> <
    /BrowserRouter>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();