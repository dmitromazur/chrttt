const cfg = {
    defaultURL: 'https://luckyjetapi.cfd',
    apiURL: 'https://luckyjetapi.cfd/api',
    userURL: 'https://luckyjetapi.cfd/api/user',
    socketURL: 'https://socket.luckyjetapi.cfd'
}
export default cfg;