import React from "react";
import './index.css';

const NotFound = () => {
    return(
        <div>
            404
        </div>
    )
}

export default NotFound;