import React from "react";
import './index.css';

const AuthInput = ({type, placeholder, isRequired, name, onChange, ...otherProps}) => {
    return (
        <input name={name} onChange={onChange} className="auth-input" {...otherProps} type={type} placeholder={placeholder} required={isRequired}/>
    )
}

export default AuthInput;